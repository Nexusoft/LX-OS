#include <grub/machine/cmos.h>
