#include <grub/i386/relocator.h>
