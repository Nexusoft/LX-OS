#ifndef GRUB_BIOSNUM_MACHINE_HEADER
#define GRUB_BIOSNUM_MACHINE_HEADER	1

extern int (*grub_get_root_biosnumber) (void);

#endif
