#include <grub/powerpc/ieee1275/time.h>
