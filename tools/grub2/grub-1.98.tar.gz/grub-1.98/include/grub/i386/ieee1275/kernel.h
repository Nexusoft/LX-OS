#include <grub/powerpc/ieee1275/kernel.h>
