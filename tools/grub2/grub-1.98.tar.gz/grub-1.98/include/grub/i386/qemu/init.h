#include <grub/i386/coreboot/init.h>
