#include <grub/cpu/loader.h>
