#include <grub/i386/coreboot/time.h>
